# History of C
1. Resource available below
[History of C](https://en.cppreference.com/w/c/language/history)
2. Summary from the internet:
ANSI and ISO are both actually the standard bodies that usually defines all the standards of the lanuage. From C90, ISO was made the standard body for C. And then based upon these standards, the standard library of C Programming Language is written.
3. POSIX is an extension to the C Programming Language, like a superset to it. And most importantly it defers to C standard. So, if there is a conflict between the two then the C standard wins. It is added because the Plain C Language doesn't provide vast majority of things.
4. GNU C is just a fancy C stuff implemented by GCC Compiler Collection.