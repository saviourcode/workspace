#ifndef _MATRIX_H_
#define _MATRIX_H_

void matrix_init();
void matrix_update();

#endif